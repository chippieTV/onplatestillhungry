<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ce:mean_removal:exp'	=>  'Uses mean removal to achieve a "sketchy" effect.',

// END
''=>''
);

/* End of file ce_image_mean_removal_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/ce_image_mean_removal/language/english/ce_image_mean_removal_lang.php */