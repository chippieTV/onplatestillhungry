<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ce:emboss:exp'	=>  'Embosses the image.',

// END
''=>''
);

/* End of file ce_image_emboss_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/ce_image_emboss/language/english/ce_image_emboss_lang.php */