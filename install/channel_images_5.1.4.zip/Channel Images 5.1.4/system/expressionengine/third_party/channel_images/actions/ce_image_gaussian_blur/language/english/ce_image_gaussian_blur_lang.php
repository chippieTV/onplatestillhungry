<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ce:gaussian_blur:exp'	=>  'Blurs the image using the Gaussian method.',

// END
''=>''
);

/* End of file ce_image_gaussian_blur_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/ce_image_gaussian_blur/language/english/ce_image_gaussian_blur_lang.php */