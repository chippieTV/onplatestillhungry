<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ce:contrast'		=>  'Contrast',
'ce:contrast:exp'	=>  'The contrast level (-100 = max contrast, 0 = no change, +100 = min contrast (note the direction!)).',

// END
''=>''
);

/* End of file ce_image_contrast_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/ce_image_contrast/language/english/ce_image_contrast_lang.php */