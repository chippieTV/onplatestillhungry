<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------
'ci:resize:percent'	=>	'Percent',
'ci:resize:percent_exp'	=>	'This resizes the image down by the amount of percent specified.',


// END
''=>''
);

/* End of file resize_percent_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/resize_percent/language/english/resize_percent_lang.php */