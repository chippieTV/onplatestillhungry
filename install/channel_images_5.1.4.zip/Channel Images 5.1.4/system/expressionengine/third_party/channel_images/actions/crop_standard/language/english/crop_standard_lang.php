<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ci:resize:startx'	=>	'Start X',
'ci:resize:starty'	=>	'Start Y',
'ci:resize:width'	=>	'Width',
'ci:resize:height'	=>	'Height',
'ci:resize:quality'	=>	'Quality',
'ci:crop:standard_exp'		=>	'Vanilla Cropping - Crops from x,y with specified width and height.',


// END
''=>''
);

/* End of file crop_standard_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/crop_standard/language/english/crop_standard_lang.php */