<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ci:resize:width'	=>	'Width',
'ci:resize:height'	=>	'Height',
'ci:resize:quality'	=>	'Quality',
'ci:crop:center_exp'		=>	'Crops an image from the center with provided dimensions. If no height is given, the width will be used as a height, thus creating a square crop.',


// END
''=>''
);

/* End of file crop_center_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/crop_center/language/english/crop_center_lang.php */