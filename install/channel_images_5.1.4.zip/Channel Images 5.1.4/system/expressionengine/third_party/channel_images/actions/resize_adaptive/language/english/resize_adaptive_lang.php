<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ci:resize:width'	=>	'Width',
'ci:resize:height'	=>	'Height',
'ci:resize:quality'	=>	'Quality',
'ci:resize:upsizing'=>	'Allow Upsizing',
'ci:resize:adaptive_exp'	=>	'This function attempts to get the image to as close to the provided dimensions as possible, and then crops the remaining overflow (from the center) to get the image to be the size specified. Additionally, if ALLOW_UPSIZING is set to YES (NO by default), then this function will also scale the image up to the maximum dimensions provided.',


// END
''=>''
);

/* End of file resize_adaptive_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/resize_adaptive_/language/english/resize_adaptive_lang.php */