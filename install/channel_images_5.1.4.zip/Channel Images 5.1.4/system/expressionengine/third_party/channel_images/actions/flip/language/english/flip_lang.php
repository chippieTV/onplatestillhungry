<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------
'ci:flip:axis'	=>	'Axis',
'ci:flip:exp'	=>	'Flips an image.',
'ci:flip:horizontal'=>	'Horizontal',
'ci:flip:vertical'	=>	'Vertical',
'ci:flip:both'		=>	'Both',


// END
''=>''
);

/* End of file flip_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/flip/language/english/flip_lang.php */