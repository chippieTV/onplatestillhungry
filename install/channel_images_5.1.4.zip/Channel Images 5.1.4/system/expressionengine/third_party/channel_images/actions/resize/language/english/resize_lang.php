<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ci:resize:width'	=>	'Width',
'ci:resize:height'	=>	'Height',
'ci:resize:quality'	=>	'Quality',
'ci:resize:upsizing'=>	'Allow Upsizing',
'ci:resize:exp'		=>	'Resizes an image to be no larger than WIDTH or HEIGHT. If either param is set to zero, then that dimension will not be considered as a part of the resize. Additionally, if ALLOW_UPSIZING is set to YES (NO by default), then this function will also scale the image up to the maximum dimensions provided.',


// END
''=>''
);

/* End of file resize_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/resize/language/english/resize_lang.php */