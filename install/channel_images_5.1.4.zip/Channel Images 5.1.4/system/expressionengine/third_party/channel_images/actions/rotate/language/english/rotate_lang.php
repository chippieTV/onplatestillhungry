<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------
'ci:rotate:degrees' =>	'Degrees',
'ci:rotate:exp'	=>	'Rotates image specified number of degrees.',
'ci:rotate:only_if'	=>	'Only If',
'ci:rotate:always'	=>	'Always Rotate',
'ci:rotate:width_bigger'=>	'Width is Longest (Landscape)',
'ci:rotate:height_bigger'=>	'Height is Longest (Portrait)',
'ci:rotate:bg_color' =>	'BG Color',

// END
''=>''
);

/* End of file rotate_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/rotate/language/english/rotate_lang.php */