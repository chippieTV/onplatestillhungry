<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ce:negate:exp'	=>  'Reverses all colors of the image.',

// END
''=>''
);

/* End of file ce_image_negate_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/ce_image_negate/language/english/ce_image_negate_lang.php */