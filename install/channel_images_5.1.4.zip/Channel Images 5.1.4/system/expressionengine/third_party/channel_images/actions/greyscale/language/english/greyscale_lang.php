<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------
'ci:greyscale:exp'	=>	'Creates a Black & White version of the image.',


// END
''=>''
);

/* End of file greyscale_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/greyscale/language/english/greyscale_lang.php */