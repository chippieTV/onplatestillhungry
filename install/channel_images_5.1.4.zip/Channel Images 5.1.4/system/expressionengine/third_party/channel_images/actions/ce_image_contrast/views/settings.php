<table cellspacing="0" cellpadding="0" border="0" class="ChannelImagesTable CITable">
	<thead>
		<tr>
			<th><?=lang('ce:contrast')?></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>
				<?=form_input($action_field_name.'[contrast]', $contrast, 'style="border:1px solid #ccc; width:80%;"')?>
				<small><?=lang('ce:contrast:exp')?></small>
			</td>

		</tr>
	</tbody>
</table>
