<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ce:edgedetect:exp'	=>  'Uses edge detection to highlight the edges in the image.',

// END
''=>''
);

/* End of file ce_image_edgedetect_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/ce_image_edgedetect/language/english/ce_image_edgedetect_lang.php */