<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ce:block_size'		=>  'Block Size',
'ce:block_size:exp'	=>  'Block size in pixels.',
'ce:advanced'		=>  'Advanced',
'ce:advanced:exp'	=>  'Whether to use advanced pixelation effect or not.',

'ce:pixelate_exp'	=>	'Applies pixelation effect to the image',

// END
''=>''
);

/* End of file ce_image_pixelate_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/ce_image_pixelate/language/english/ce_image_pixelate_lang.php */