<?php if (!defined('BASEPATH')) die('No direct script access allowed');

$lang = array(


//----------------------------------------

'ce:brightness'		=>  'Brightness',
'ce:brightness:exp'	=>  'The brightness level (-255 = min brightness, 0 = no change, +255 = max brightness).',

// END
''=>''
);

/* End of file ce_image_brightness_lang.php */
/* Location: ./system/expressionengine/third_party/channel_images/actions/ce_image_brightness/language/english/ce_image_brightness_lang.php */