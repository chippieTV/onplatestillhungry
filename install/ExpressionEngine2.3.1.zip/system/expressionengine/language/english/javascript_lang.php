<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang = array(


''=>''
);

/* End of file javascript_lang.php */
/* Location: ./system/expressionengine/language/english/javascript_lang.php */