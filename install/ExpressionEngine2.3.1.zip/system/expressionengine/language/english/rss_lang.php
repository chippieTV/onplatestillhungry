<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

'rss_module_name' =>
'RSS',

'rss_module_description' =>
'RSS page generating module',

//----------------------------------------

'rss_invalid_channel' =>
'The channel specified in your RSS feed does not exist.',


''=>''
);

/* End of file rss_lang.php */
/* Location: ./system/expressionengine/language/english/rss_lang.php */