<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

'query_module_name' =>
'Query',

'query_module_description' =>
'SQL query module for templates',

//----------------------------------------



''=>''
);

/* End of file query_lang.php */
/* Location: ./system/expressionengine/language/english/query_lang.php */