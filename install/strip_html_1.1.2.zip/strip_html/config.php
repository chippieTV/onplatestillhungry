<?php

  $config['name']='Strip_HTML';
  $config['version']='1.1.2';
  $config['nsm_addon_updater']['versions_xml'] = 'http://ingowedler.com/appcast/ee/strip_html.xml';
  
?>